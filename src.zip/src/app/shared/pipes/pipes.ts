
import { KeysPipe } from './keys/keys.pipe';

export const Pipes = [
    KeysPipe
];
